#ifndef TFT_dorianStuff_cpp
#define TFT_dorianStuff_cpp
#include <TFT_eSPI.h> 


//POSSIBLE UPGRADE TO SCREEN RATIOS.
//use uint8_t precentage for height and width;
// use uint8_t alignment code l up down md right ect
//then slide elements into place based on order they are called in the array of  elements
// ie most element will be either top to bottom or left to right so if all of
//the elements are alignmentCode "left top" they will go up in the order they were written
// this could cause problems for createing specific rows



class saveInFavorites{
    public:


};
class valueAdd{
    public:
uint16_t Maximum , adjustAmount;
uint16_t *value;
 
    valueAdd(uint16_t *ptr, uint16_t amount, uint16_t max){
        value = ptr; adjustAmount = amount; Maximum = max;  }

};
class valueSub{
    public:
uint16_t minimum , adjustAmount;
uint16_t *value;
 
    valueSub(uint16_t *ptr, uint16_t amount, uint16_t min){
        value = ptr; adjustAmount = amount; minimum = min;  }

};

class OpenPopup{
uint8_t identifier[4];
uint16_t *value;

};



typedef void (*buttonFunction)(int16_t, int16_t); //std::array needs a named type to work. doensn't like to much stuff in its declaration

class DButton : public TFT_eSPI_Button {
public:
void setLabel(char *s){   strncpy(_label, s, 9);}

DButton(char * s){ strncpy(_label, s, 9);}

DButton(){}

    std::array<buttonFunction, 0> funcList; 

};
class tftAnimator{ //tft animator may need to be added as an argument to tftElementDefiner;
    int16_t xPos;

    int16_t tileWidth;

    int xScrollPadding;

    int radus;

    int lastTime;
    int millis;
    //color Animation?

};
class tftPallet
{
    public:
    uint16_t fill;
    uint16_t border;
    uint16_t text;

    tftPallet( uint16_t fillColor , uint16_t borderColor, uint16_t textColor) {
        fill= fillColor; text = textColor; border = borderColor;
    }

};

class tftStyler{
  public:
  //char *label; no font because this is content
  uint16_t fillColor;
  uint16_t borderColor;
  uint16_t fontColor;

  //uint8_t borderThickness;

  uint8_t radius;     //maybe make radius a ratio aswell
  int8_t widthAdjust;   //maybe change to a Float???  or a percentage out of 100 or a percentage up or down from 0
  int8_t heightAdjust;
  uint8_t fontSizeMultiplier=1;//=1;  //maybe move Pallet???
  //maybe make a font class

  void shrinkDimensions(uint8_t x, uint8_t y){ widthAdjust = x; heightAdjust = y; return;} //use Shape
  void colors(uint16_t color,  uint16_t border, uint16_t text ){ fillColor = color; fontColor = text; borderColor = border;  return;}
  void shape(uint16_t rad, int8_t adjWid=0, int8_t adjHgt=0){ radius = rad; widthAdjust = adjWid; heightAdjust= adjHgt; return;}
 
 tftStyler(){};
 tftStyler( tftPallet pallet, uint16_t rad, uint16_t adjWid=0, uint16_t adjHgt=0, uint8_t fontSize=1){
   fillColor = pallet.fill; borderColor = pallet.border;  fontColor = pallet.text;  radius = rad; widthAdjust = adjWid; heightAdjust= adjHgt; fontSizeMultiplier = fontSize;
 }
  
   



};

class tftRatioPosition{
    public:
    uint8_t nElementW;
    uint8_t posX;
    uint8_t nElementH;
    uint8_t posY;
    uint8_t width;// in number of button incriments
    uint8_t height; //also not yet impelmented


tftRatioPosition(uint8_t numOfButtonsWide, uint8_t positionX, uint8_t numOfButtonsHigh, uint8_t positionY, uint8_t buttonW=1, uint8_t buttonH=1){
   nElementW =numOfButtonsWide;  
   posX =  positionX;
   nElementH = numOfButtonsHigh;
   posY = positionY;
   width = buttonW ;
   height = buttonW ;

}

};
class shapeDefiner{ //used for all shapes
public:

};

class tftElementDefiner {//Rename to tftElementDefiner

public:
  //  uint8_t numOfButtons;
    tftRatioPosition *posPtr; //these pointers Are not used
    tftStyler *stylerPtr;
    tftPallet *palletPtr;
    uint16_t  screenSizeX, screenSizeY;
    TFT_eSPI *tft;

   tftElementDefiner(TFT_eSPI &tfT, int x ,int y){ 
    screenSizeX = x;   screenSizeY = y;     tft = &tfT;}

    void setScreen(TFT_eSPI &tfT, int x ,int y){ //probably should depreciate// but may be usefule for multiple screens
    screenSizeX = x;   screenSizeY = y;     tft = &tfT;}

    //IT IS IMPORTANT TO NOTE THE DButtons only exist in memory they do not exist in any of my objects in storage
    // this being the case it may make sense to rename this function  to Create button.

    void createButton(DButton &key,tftStyler style, uint8_t numOfButtonsWide, uint8_t positionX, uint8_t numOfButtonsHigh, uint8_t positionY, uint8_t numWide=1, uint8_t numDown=1){


    uint16_t tileWidth = (screenSizeX/numOfButtonsWide); //always round down size
    uint16_t tileHeight = screenSizeY/numOfButtonsHigh; //always round down size
      
      uint16_t PosX = tileWidth/2 + positionX*tileWidth; 
       PosX = PosX + ((tileWidth*numWide) - tileWidth)/2; //add in offset for wide buttons
      
         uint16_t PosY = tileHeight/2 + positionY*tileHeight; 
       PosY = PosY + ((tileHeight*numDown) - tileHeight)/2; //add in offset for wide buttons

     // uint16_t smallerDim;
        //if(tileWidth<height){ smallerDim = tileWidth;}else{smallerDim = height;} //for ratio radius

          key.initButton(tft,   PosX,PosY , // X Y //add some animation later!
                            tileWidth*numWide + style.widthAdjust,
                            tileHeight*numDown +style.heightAdjust ,
                            style.radius,//smallerDim/style.radius, //w, h, rad
                            style.borderColor, style.fillColor, style.fontColor,  // outline, fill, text
                            key._label , style.fontSizeMultiplier);  // maybe put the font stuff in a new class

                
                           //I believe the font is handled in tft as a ptr to the "current" set font
                            //  GFXfont  *gfxFont;
                            // so in order to change font we would need to change the pointer somewhere in here
                    
    return;
    }
    void createButton(DButton &key,tftStyler style, tftRatioPosition pos){
         createButton(key, style, pos.nElementW , pos.posX, pos.nElementH, pos.posY);
     }


    //type 0 border and fill; type 1 border; type 2 fill;
    void createRectangle(uint8_t type, tftStyler style, uint8_t numOfButtonsWide, uint8_t positionX, uint8_t numOfButtonsHigh, uint8_t positionY,uint8_t numWide=1, uint8_t numDown=1){
            uint16_t tileWidth = screenSizeX/numOfButtonsWide; //always round down size
            uint16_t tileHeight = screenSizeY/numOfButtonsHigh; //always round down size
      

             
        if(type==0 || type==2){
            tft->fillRoundRect(   positionX*tileWidth  - (style.widthAdjust/2),   ///X posion  
                                  positionY*tileHeight - (style.heightAdjust/2), // Y 
                                   tileWidth*numWide + style.widthAdjust, 
                                   tileHeight*numDown +style.heightAdjust , 
                                   style.radius, style.fillColor);  

        }
        if(type==0 || type==2){                         
              tft->drawRoundRect(  positionX*tileWidth  - (style.widthAdjust/2),   ///X posion  
                                   positionY*tileHeight - (style.heightAdjust/2), // Y 
                                   tileWidth*numWide + style.widthAdjust, 
                                   tileHeight*numDown +style.heightAdjust , 
                                   style.radius, style.borderColor);
        }                          
                                   
       }
    void createElipse(uint8_t type, tftStyler style, uint8_t numOfButtonsWide, uint8_t positionX, uint8_t numOfButtonsHigh, uint8_t positionY,uint8_t numWide=1, uint8_t numDown=1){
        
    uint16_t tileWidth = (screenSizeX/numOfButtonsWide); //always round down size
    uint16_t tileHeight = screenSizeY/numOfButtonsHigh; //always round down size
      
      uint16_t PosX = tileWidth/2 + positionX*tileWidth; 
       PosX = PosX + ((tileWidth*numWide) - tileWidth)/2; //add in offset for wide buttons
      
         uint16_t PosY = tileHeight/2 + positionY*tileHeight; 
       PosY = PosY + ((tileHeight*numDown) - tileHeight)/2; //add in offset for wide buttons

             
        if(type==0 || type==2){
            tft->fillEllipse(    PosX,PosY ,   ///X posion  
                                
                                  (tileWidth*numWide + style.widthAdjust)/2, 
                                   (tileHeight*numDown + style.heightAdjust)/2 , 
                                    style.fillColor);  
                                    
         
        }
        if(type==0 || type==1){                         
               tft->drawEllipse(    PosX,PosY ,   ///X posion  
                                
                                  (tileWidth*numWide + style.widthAdjust)/2, 
                                   (tileHeight*numDown + style.heightAdjust)/2 , 
                                    style.borderColor);  
        }                          
                                   
       }
    void createText18MC(const char *string, tftStyler style, uint8_t numOfButtonsWide, uint8_t positionX, uint8_t numOfButtonsHigh, uint8_t positionY,uint8_t numWide=1, uint8_t numDown=1){
      uint16_t tileWidth = (screenSizeX/numOfButtonsWide); //always round down size
    uint16_t tileHeight = screenSizeY/numOfButtonsHigh; //always round down size
      
      uint16_t PosX = tileWidth/2 + positionX*tileWidth; 
       PosX = PosX + ((tileWidth*numWide) - tileWidth)/2; //add in offset for wide buttons
      
         uint16_t PosY = tileHeight/2 + positionY*tileHeight; 
       PosY = PosY + ((tileHeight*numDown) - tileHeight)/2; //add in offset for wide buttons

        tft->setTextDatum(MC_DATUM);        // Use top left corner as text coord datum

      tft->setFreeFont(&FreeSansBold18pt7b);  // Choose a nicefont that fits box
      tft->setTextColor(style.fontColor);     // Set the font colour

      // Draw the string, the value returned is the width in pixels
       int xwidth =  tft->textWidth(string);//unused this is to get the textWidth without drawing string for use later with mulitline or scrolling text

      tft->drawString(string,PosX,PosY ); //returns a value but no point in using it here.
    }

};
    class tftFontInfo{
    public:
    //tftFontInfo(const GFXfont *f = NULL,tftStyler style,uint8_t numRows){

    //}

    };
class Screen {

//layouts list
//functions list possibly

//void valueChanger(int x, int x);
//void popUpCaller(ScreenIdentifier *xxx, bool isOnScreen); //
uint8_t identifier [5];
uint8_t numberOfButtons;
tftElementDefiner  *fullLayout;

//Screen(uint8_t *ident, la )
};


/*
globalData
CurrentScreenId,prevSCreenId
    Led Mode settings
    -modeId/name
    -modeIndex/array#
    -settingData
Dbutton
-dimensions and colors
-label  xxxxxxxx

-functioner*?xxxxxxxxxx


Dbutton = buttonDefiner(functioner(), positioner, styler, labelIDdiciontary);

functioners
-popup()
-newScreen(nextScreenId,thisScreenId)
-valueAjust(valuetochane, change amount int)
-colorPicker(&valueToChange  ) button hieght, //no need to put the popup in becuase it is the color picker



styler
-colors
-size ajustments



*/

/*
buttonDefiner twoColorGradient = {  buttonDefiner(valueChange(setting0, -1), leftRow1, white, _id.down), buttonDefiner(valueChange(setting0, 1), rightRow1, white, _id.up),
                                    buttonDefiner(valueChMult(setting1, -1), leftRow2, white, _id.down), buttonDefiner(valueChMult(setting1, 1), rightRow2, white, _id.up),


*/

#endif